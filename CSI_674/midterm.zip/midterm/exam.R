### Bayesian Inference and Decision Theory ###

# Problem 2 - Teacher's Prior Distribution

# Calculate deviation of teacher's quantiles from Beta quantiles
cdfvals=c(0.30, 0.45, 0.55, 0.65)    # values of teacher's cdf
quantiles=c(2/1000,1/100,1/50,2/50)  # pass rate for cdf values

mean = seq(from=1/100, by=0.0005, length=120)
vcount = seq(from=1, by=0.2, length=61)
maxDev=100
for (m in mean) {
  for (vc in vcount) {
    alpha=m*vc
    beta=vc-alpha
    dev=sum((pbeta(quantiles,alpha,beta)-cdfvals)^2)
    if (dev<maxDev) {
      maxDev=dev
      alpha.opt=alpha
      beta.opt=beta
    } 
  }
}

pbeta(quantiles,alpha.opt,beta.opt)

# Or use R's nlm optimization function
deviation=function(param) {
  sum((pbeta(quantiles,param[1],param[2])-cdfvals)^2)
}
nlm(deviation,c(0.3,8))
