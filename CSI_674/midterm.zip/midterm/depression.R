### Bayesian Inference and Decision Theory ###

# Midterm 2020 Problems 4 - 6
# Efficacy of drug for treating depression

# Problem 4 - joint posterior distribution of improvement probability for
# treatment and control

# Study results
k.trt=42    # Number of non-improvement in treatment group
n.trt=60    # Number of improvements in treatment group
k.ctl=34    # Number of non-improvements in control group
n.ctl=60    # Number of improvements in control group

#Prior hyperparameters
alpha.0 =0.5
beta.0=0.5

# Posterior hyperparameters
alpha.trt=alpha.0 + k.trt
beta.trt=beta.0 + n.trt-k.trt
alpha.ctl=alpha.0 + k.ctl
beta.ctl=beta.0 + n.ctl-k.ctl

# Posterior credible intervals
trt.intrv=qbeta(c(0.025,0.975),alpha.trt,beta.trt)
ctl.intrv=qbeta(c(0.025,0.975),alpha.ctl,beta.ctl)

# Plot the two posterior density functions
theta=seq(length=200,from=.4,to=0.99)
post.trt=dbeta(theta,alpha.trt,beta.trt)
post.ctl=dbeta(theta,alpha.ctl,beta.ctl)
plot(theta,post.trt,type="l",col="red",main="Treatment and Control Comparison",
     xlab="Probability of Improvement",ylab="Posterior Probability Density")
lines(theta,post.ctl,col="blue")
legend(0.8,6,c("Treatment","Placebo"),col=c("red","blue"),lty=c(1,1))

# Add the credible intervals to the plot
points(trt.intrv,c(0.01,0.01),col="red",pch="x")
lines(trt.intrv,c(0.01,0.01),col="red")
points(ctl.intrv,c(0.04,0.04),col="blue",pch="x")
lines(ctl.intrv,c(0.04,0.04),col="blue")

# Plot the joint posterior distribution
# Many students are confused between joint posterior and 
# combined posterior if theta1 and theta2 are assumed equal
# Joint posterior distribution is a function of two
# variables, theta1 and theta2

gs<-200        # grid size
theta.t<-seq(0.55,0.85,length=gs)   # treatment mean
theta.c<-seq(0.42,0.70 ,length=gs)  # control mean

dens<-matrix(0,gs,gs)             # density function
for(i in 1:gs) {
  dens[i,]=dbeta(theta.t[i],alpha.trt,beta.trt) * dbeta(theta.c,alpha.ctl,beta.ctl)
}

# Perspective plot

persp(theta.t,theta.c,dens,theta=30,phi=5,xlab="Treatment Relapse Prob",
      ylab="Control Relapse Prob",zlab="Probability Density",
      xlim=theta.t[c(1,gs)] ,ylim=theta.c[c(1,gs)],
      main="Joint Density for Treatment and Control Improvement Probs")


# Problem 5 - Monte Carlo sample to estimate probability treatment is
# better than control

# Draw a sample of values from joint posterior distribution of
# treatment and control relapse rates
nsample=5000
treat=rbeta(nsample,alpha.trt,beta.trt)
contr=rbeta(nsample,alpha.ctl,beta.ctl)
diff=treat-contr     # Estimate of difference in improvement probs
efficacious=diff>0   # Prob treatment is better
prob.efficacious=sum(efficacious)/nsample
sd.probefficacious = sd(efficacious)/sqrt(nsample)

#Posterior quantiles, mean and standard deviation
quantile(diff,c(0.05,0.5,0.95))
mean(diff)
sd(diff)

#Density Function for Difference in Treatment and Control Relapse Probabilities
plot(density(diff),main="Kernel Density Estimator",
     xlab="Difference in Treatment and Control Probabilities",
     ylab="Posterior Probability Density")

# Problem 5 - Posterior predictive distribution for number of
# patients improving if given the new drug

# Posterior predictive
# Load package for Beta-Binomial functions
require(rmutil)         # Load the VGAM package (do this on restarting R if you want to use the package)

bbprob = alpha.trt/(alpha.trt+beta.trt)
ovrdisp = alpha.trt+beta.trt

pred.mean = 25*bbprob
pred.var = 250*bbprob*(1-bbprob)*(ovrdisp+50)/(ovrdisp+1)
pred.SD = sqrt(pred.var)
pred.95.interval = qbetabinom(c(0.025,0.975),25,bbprob,ovrdisp)
prob.in.interval = sum(dbetabinom(pred.95.interval[1]:pred.95.interval[2],
                                  25,bbprob,ovrdisp))

prob.ge.20 = 1-pbetabinom(19, 25,bbprob,ovrdisp) # Prob 20 or more improve

# Make the plot
predict=dbetabinom(0:25,25,bbprob,ovrdisp)    # Marginal likelihood predictive distribution
binom=dbinom(0:25,25,k.trt/n.trt)                    # Binomial pmf
barplot(rbind(predict,binom),beside=TRUE,
        main = "Predicted Number of Patients Given Drug who Improve",
        ylab="Probability",xlab="Number of Relapses",
        legend.text=c("Beta-Binomial", "Binomial"),
        args.legend=list(x="topleft"),col=c("lightblue","pink"), 
        border=c("darkblue","red"),names.arg=0:25)

