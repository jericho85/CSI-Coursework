### Bayesian Inference and Decision Theory ###

# Midterm 2020 Problems 9 & 10 - Call Times at Call Center

#### Installing invgamma package ####
# Run the commented line of code below to install the invgamma package
# After being run once it does not need to be run again until you re-install R
# install.packages("invgamma")

# Load inverse gamma package packages it depends on
library('invgamma')   # Functions for inverse gamma distribution

# Problem 9

# The mean time between calls is exponential with mean theta. The number of
#   calls arriving per second is Poisson with mean lambda = 1/theta. 
#   theta has inverse-gamma distribution
#   lambda has gamma distribution

# Transform raw call times into intervals between calls
callTimeSeconds=c(168,  314,  560,  754, 1215, 1493, 
                  1757, 1820, 1871, 1982, 2134, 2430, 3187, 3388, 3485)
callIntervals=callTimeSeconds-
  c(0,callTimeSeconds[1:(length(callTimeSeconds)-1)])

n=length(callIntervals)    # number of observations
sumx=sum(callIntervals)    # sum of observations

# Prior hyperparameters
alpha0=4
beta0=0.0015

# Prior Mean, Std Deviation, quantiles
prior.mean = ((alpha0-1)*beta0)^-1
prior.var = ((alpha0-1)^2*(alpha0-2)^1*beta0^2)^-1
prior.sd = sqrt(prior.var)

q.prior.gamma.025 = qgamma(0.025,shape=alpha0,scale=beta0)
q.prior.gamma.5 = qgamma(0.5,shape=alpha0,scale=beta0)
q.prior.gamma.975 = qgamma(0.975,shape=alpha0,scale=beta0)

prior.025 = 1/q.prior.gamma.975  #same as qinvgamma(0.025,alpha0,1/beta0)
prior.5 = 1/q.prior.gamma.5      #same as qinvgamma(0.5,alpha0,1/beta0)
prior.975 = 1/q.prior.gamma.025  #same as qinvgamma(0.975,alpha0,1/beta0)

# Posterior hyperparameters
alpha1=alpha0+length(callIntervals)
beta1=1/(1/beta0+sum(callIntervals))

# Triplot for Theta
thetavals=seq(length=100,from=10,to=500)
prior.dens=dinvgamma(thetavals,shape=alpha0,scale=beta0)  
norm.lik=dinvgamma(thetavals,n-1,scale=1/sumx)
post.dens=dinvgamma(thetavals,shape=alpha1,scale=beta1)
plot(thetavals,prior.dens,type="l",col="blue",main="Triplot for Mean Time Between Calls",
     xlab="Mean Time Between Calls (seconds)",ylab="Probability Density",
     xlim=c(0,500),ylim=c(0,0.01))
lines(thetavals,norm.lik,col="green")
lines(thetavals,post.dens,col="red")
legend(320,0.008,c("Prior","Norm Lik","Posterior"),col=c("blue","green","red"),lty=c(1,1,1))

# Triplot for Lambda = Theta^-1 (not required but useful for understanding)
lambdavals=seq(length=100,from=0.0005,to=0.01)
prior.l.dens=dgamma(lambdavals,shape=alpha0,scale=beta0)  
norm.l.lik=dgamma(lambdavals,shape=n-1,scale=1/sumx)
post.l.dens=dgamma(lambdavals,shape=alpha1,scale=beta1)
plot(lambdavals,prior.l.dens,type="l",col="blue",
     main="Triplot for Mean Number of Calls per Second",
     xlab="Mean Number of Calls",ylab="Probability Density",
     xlim=c(0,0.01),ylim=c(0,400))
lines(lambdavals,norm.l.lik,col="green")
lines(lambdavals,post.l.dens,col="red")
legend(0.007,320,c("Prior","Norm Lik","Posterior"),col=c("blue","green","red"),lty=c(1,1,1))


# Posterior Mean, Std Deviation, quantiles
post.mean = ((alpha1-1)*beta1)^-1
post.var = ((alpha1-1)^2*(alpha1-2)^1*beta1^2)^-1
post.sd = sqrt(post.var)

q.post.gamma.025 = qgamma(0.025,shape=alpha1,scale=beta1) 
q.post.gamma.5 = qgamma(0.5,shape=alpha1,scale=beta1)     
q.post.gamma.975 = qgamma(0.975,shape=alpha1,scale=beta1) 

post.025 = 1/q.post.gamma.975   #same as qinvgamma(0.025,alpha1,1/beta1)
post.5 = 1/q.post.gamma.5       #same as qinvgamma(0.5,alpha1,1/beta1)
post.975 = 1/q.post.gamma.025   #same as qinvgamma(0.975,alpha1,1/beta1)


q.gamma.025 = qgamma(0.025,shape=alpha1,scale=beta1)
q.gamma.975 = qgamma(0.975,shape=alpha1,scale=beta1)

q.invgamma.025 = 1/q.gamma.975
q.invgamma.975 = 1/q.gamma.025


# Problem 10
exp.quantiles=qexp(ppoints(length(callIntervals)))
qqplot(exp.quantiles, callIntervals,
       main="Exponential Q-Q Plot",
       xlab="Exponential Quantiles",
       ylab="Observed Quantiles")
lines(exp.quantiles,exp.quantiles*mean(callIntervals))  # Overlay a line

# Kolmogorov-Smirnov Test for Exponential Distribution
ks.test(callIntervals,"pexp",1/mean(callIntervals))

plot(callIntervals[1:14],callIntervals[2:15],
     main="Lagged Plot of Call Intervals",
     xlab="Call Interval", ylab = "Next Call Interval")
plot(1:15,callIntervals,main="Time Series Plot of Call Intervals")

