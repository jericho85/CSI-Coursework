### Bayesian Inference and Decision Theory ###

# Midterm 2020 Problems 7 and 8 - Plant Growth

# Problem 7
# Predictive distribution

alpha = 2    # shape parameter
beta = 6     # scale parameter

nplots = 5   # number of plots to predict

# Predictive distribution is negative binomial with size alpha
# and probability 1/(1+nplots*beta)

# Plot the predictive distribution and Poisso distribution with
# same expectation for comparison
xvals=1:180     # Range of values to plot (set by trial and error)
dpred = dnbinom(1:180, size=alpha, prob=1/(1+nplots*beta)) # Predictive
dpois = dpois(xvals,alpha*beta*nplots)  # Poisson with point estimate
barplot(rbind(dpred,dpois),
        main="Predictive Distribution for Plant Counts", 
        xlab="Number of Plants Growing in 5 Plots", ylab="Probability", 	
        col=c("lightblue","pink"), 
        border=c("darkblue","red"),names.arg=xvals, beside=TRUE,
        legend=c("Predictive","Poisson"))


# Problem 8
# Find posterior distribution
observedTotal = 72

alpha.star = alpha + observedTotal
beta.star = (1/beta + nplots)^-1

interval = qgamma(c(0.025, 0.975), shape=alpha.star, scale=beta.star)

# Do a triplot
plotlim = qgamma(c(0.005, 0.995), shape=alpha.star, scale=beta.star)
lambda=seq(length=100,from=plotlim[1],to=plotlim[2])
priorDens=dgamma(lambda,shape=alpha,scale=beta) # Prior density
postDens=dgamma(lambda,shape=alpha.star,scale=beta.star)  # Posterior density
normLik=dgamma(lambda,               # Normalized Likelihood is Gamma(6,1/6)
                shape=observedTotal+1,scale=1/nplots)    

plot(lambda,priorDens,type="l",col="blue",main="Triplot for Poisson Mean",
     xlab="Mean Number of Plants Per Plot",ylab="Probability Density",
     xlim=plotlim,ylim=c(0,max(postDens)))
lines(lambda,normLik,col="green")
lines(lambda,postDens,col="red")
legend(16.5,0.2,c("Prior","Norm Lik","Posterior"),col=c("blue","green","red"),lty=c(1,1,1))
