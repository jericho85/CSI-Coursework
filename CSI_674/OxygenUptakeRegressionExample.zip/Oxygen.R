# Oxygen uptake example from Hoff text
age = c(23,22,22,25,27,20,31,23,27,28,22,24)
aerobic=c(array(0,6),array(1,6))
y=c(-0.87,-10.74,-3.27,-1.97,7.5,-7.25,17.05,4.96,10.4,11.05,0.26,2.51)

lmfit=lm(y~age*aerobic)
summary(lmfit)

# Hierarchical model in JAGS

require(R2jags)
set.seed(12345)

numSim=10000
numBurnin=1000

n=length(y)
oxygen.data=c("y","age","aerobic","n")
oxygen.inits = function() {
	list("a"=c(0,0), "b"=c(0,0), "rho"=1)
	}
oxygen.params=c("a","b","rho")

# Fit the model in JAGS (make sure working directory is pointed to location of model file)
oxygen.jags.fit <- jags(oxygen.data,inits=oxygen.inits,oxygen.params,model.file="Oxygen.model.jags",n.iter=numSim,n.burnin=numBurnin)

oxygen.mcmc <- as.mcmc(oxygen.jags.fit)

summary(oxygen.mcmc)

oxygen.samples <- as.matrix(oxygen.mcmc)
diff=NULL
q=NULL
for (i in 22:31) {
	d=oxygen.samples[,2]-oxygen.samples[,1]+(oxygen.samples[,4]-oxygen.samples[,3])*i
	diff=cbind(diff,d)
	q=cbind(q,quantile(d,c(0.025,0.25,0.5,0.75,0.975)))
}

plot(22:31,q[3,],ylim=c(-10,15),xlab="Age",ylab="95% Interval for Aerobics Effect",pch="x")
for (i in 1:10) {
	lines(c(i+21,i+21),c(q[1,i],q[5,i]))
}
lines(22:31,array(0,10),col="gray")

# Add new observation with missing age
age[13]=NA      # Add observation with missing age
aerobic[13]=1   # Person with unknown age was on aerobic program
y[13]=5.5       # Oxygen update for person with unknown age

n=length(y)
oxygen.data=c("y","age","aerobic","n")
oxygen.params=c("a","b","rho","age13")

# Fit the model in JAGS (make sure working directory is pointed to location of model file)
oxygen.jags.m.fit <- jags(oxygen.data,parameters.to.save=oxygen.params,model.file="Oxygen.model.missing.jags",n.iter=numSim,n.burnin=numBurnin)

oxygen.m.mcmc <- as.mcmc(oxygen.jags.m.fit)

summary(oxygen.m.mcmc)

plot(oxygen.mcmc,ask=TRUE)

