# OR 664 / SYST 664 / CSI 674 Spring 2019
# Assignment 5 
# Continued analysis of automobile arrival data

#Posterior hyperparameters from HW4 Problem 1
# We started with uniform prior (Gamma with shape 1 and scale infinity)
# The observations were 40 cars in 21 time periods
alpha = 41       # Posterior shape is 1+40 = 41
beta = 1/21      # Posterior scale is 1/(1/Infinity + 21)

# Poisson / Gamma predictive distribution for next n time periods 
#  is negative binomial distribution with parameters as in Unit 3 notes
size = alpha     # size parameter is shape of the gamma distribution
n = 1            # we are predicting n future time periods
prob = 1/(1 + n*beta)   # prob parameter of negative binomial

# Calculate Bayesian predictive probabilities 
predictive_probs = dnbinom(0:4, size=size, prob=prob)  # probs of 0 to 4 cars
predictive_probs[6]=1-sum(predictive_probs)            # prob of 5 or more cars
round(predictive_probs,4)         # Print probabilitiy values to console

# Calculate Poisson probabilities with point estimate of mean
poisson_probs = c(dpois(0:4,n*alpha*beta),1-sum(dpois(0:4,n*alpha*beta))) 

bar_labels = c(0:4,"5+")
PredPois=rbind(predictive_probs,poisson_probs)         # Bind into matrix for bar chart
barplot(PredPois,main="Predictive Distribution for Car Counts in 1 Period", 
        xlab="Number of Cars", ylab="Probability", 	col=c("lightblue","pink"), 
        border=c("darkblue","red"),names.arg=bar_labels, beside=TRUE,
        legend=c("Negative Binomial","Poisson"))
        
# What about predicting the next 21 time periods? 
n = 21            # we are predicting n future time periods
prob = 1/(1 + n*beta)   # prob parameter of negative binomial

# Calculate Bayesian predictive probabilities 
# We expect around 41 cars, so look at range from 20 to 65
car_range = 20:65
predictive_probs = dnbinom(car_range, size=size, prob=prob)  # probs of 0 to 4 cars

# Calculate Poisson probabilities with point estimate of mean
poisson_probs = c(dpois(car_range,n*alpha*beta)) 

bar_labels = car_range
PredPois=rbind(predictive_probs,poisson_probs)         # Bind into matrix for bar chart
barplot(PredPois,main="Predictive Distribution for Car Counts in 21 periods", 
        xlab="Number of Cars", ylab="Probability", 	col=c("lightblue","pink"), 
        border=c("darkblue","red"),names.arg=bar_labels, beside=TRUE,
        legend=c("Negative Binomial","Poisson"))

