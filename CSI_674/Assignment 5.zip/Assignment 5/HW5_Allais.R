# Assignment 5 Problem 2 - Allais data

# Part a - analysis of prior distribution
# Prior hyperparameters
alpha0=1
beta0=3

# Mean, standard deviation and quantiles of prior distribution
alpha0/(alpha0+beta0)
sqrt(alpha0*beta0/((alpha0+beta0)^2*(alpha0+beta0+1)))
qbeta(0.025,alpha0,beta0)
qbeta(0.5,alpha0,beta0)
qbeta(0.975,alpha0,beta0)

# Part b - prior to posterior inference
# Data
x1 = 19
n1 = 47

alpha1 = alpha0 + x1      # posterior shape 1
beta1 = beta0 + n1 - x1   # posterior shape 2

# Plot of prior density
plot(seq(from=0.01,to=0.99,length=200),priorDens,type="l",col="blue",
     main="Prior Distribution for Choice in Allais Problem",
     xlab="Probability of Choosing B&C",ylab="Probability Density")

# Mean, standard deviation and quantiles of posterior distribution
alpha1/(alpha1+beta1)
sqrt(alpha1*beta1/((alpha1+beta1)^2*(alpha1+beta1+1)))
qbeta(0.025,alpha1,beta1)
qbeta(0.5,alpha1,beta1)
qbeta(0.975,alpha1,beta1)

# Triplot for 2009 data
pr=seq(from=0.01,to=0.99,length=200)
priorDens=dbeta(pr,shape1=alpha0,shape2=beta0) # Prior density
postDens=dbeta(pr,shape1=alpha1,shape2=beta1)  # Posterior density
normLik=dbeta(pr,shape1=x1,shape2=n1-x1)       # Normalized Likelihood is Beta(x,n-x)

plot(pr,priorDens,type="l",col="blue",
     main="Triplot for Allais Data (2009)",
     xlab="Probability of Choosing B&C",ylab="Probability Density",
     xlim=c(0,1),ylim=c(0,6))
lines(pr,normLik,col="green")
lines(pr,postDens,col="red")
legend(0.7,5,c("Prior","Norm Lik","Posterior"),
       col=c("blue","green","red"),lty=c(1,1,1))

# part c - simulation from posterior distribution
simPi = rbeta(10000, shape1=alpha1, shape2=beta1)

# Monte Carlo estimates of  posterior mean, standard deviation, 
# quantiles 
mean(simPi)
sd(simPi)
quantile(simPi,0.025)
median(simPi)
quantile(simPi,0.975)

# Plot kernel density estimator and theoretical distributions on same axis
plot(density(simPi), main="Posterior Density - Exact and Approximate",
     xlab="Probability of B&C")
lines(pr,postDens,col="red")
legend(0.47,5, c("Kernel Density Estimate","Exact Density"),
       col=c("black","red"),lty=c(1,1))

# Part d - Predictive distribution

# The predictive distribuiton for a binomial random variable with a
# beta prior distribution is a member of the Beta-Binomial family
# of distributions.

# We will use the beta-binomial functions from the rmutil package
# which can be installed directly from CRAN
# Once the package has been installed, it will be available
# until you update R, but it needs to be loaded every time
# you restart R
install.packages("rmutil")  # only need to run this once 
library(rmutil)             # run this every time you restart R

# Use beta-binomial distribution
#  size (number of trials to predict) = 50
#  probability = alpha1/(alpha1+beta1)
#  overdispersion = alpha1 + beta1

# range of values is 0 to 50. We will plot the whole range, although
# values below 5 or above 35 are very unlikely

bayes_pred = dbetabinom(0:50, 50, alpha1/(alpha1+beta1), alpha1 + beta1)

# binomial predictive distribution for comparison
binom_pred = dbinom(0:50, 50, alpha1/(alpha1+beta1))

# do comparison plot
bar_labels = 0:50
Compare=rbind(bayes_pred,binom_pred)         # Bind into matrix for bar chart
barplot(Compare,main="Predictive Distribution for 50 New Allais Responses", 
        xlab="Number B&C Choices", ylab="Probability", 	col=c("lightblue","pink"), 
        border=c("darkblue","red"),names.arg=bar_labels, beside=TRUE,
        legend=c("Beta-Binomial","Poisson"))

# To find 90% intervals for beta-binomial and Poisson we find
# quantiles and then find probability of enclosed points
qbetabinom(c(0.05,0.95),50, alpha1/(alpha1+beta1), alpha1 + beta1)
qbinom(c(0.05,0.95),50, alpha1/(alpha1+beta1))

# Probability enclosed in intervals
sum(dbinom(14:25,50, alpha1/(alpha1+beta1)))
sum(dbetabinom(c(14:25),50, alpha1/(alpha1+beta1), alpha1 + beta1))
